---
name: content-skill-stack
description: Takes a short-form video (Reel, TikTok, Short) from raw idea to posted and tracked, using Sam Gaudet's 6 core creator skills. The six are ideation (topic + angle + format), outlining (Hook, Explain, Illustrate, Teach), delivery ("trail, not a rail"), production (retention roadmaps), distribution (trial reel first, then main feed) and analytics (a views / followers / leads scorecard). Use this when the user wants to plan or package a whole video end to end. Also use it when they want to know why their content isn't working, which part of their process is weak, or how to track content performance and turn views into leads. It covers requests for a content scorecard or content tracking sheet too, even if they never mention "skills" or Sam Gaudet. For only a hook, or only a script in one specific framework, prefer the dedicated hook or script skills.
---

# Content Skill Stack

Source: Sam Gaudet (@sam.gaudet). He says a creator needs to master six skills, and a video
only goes as far as its weakest one. Use the stack in one of two ways:

- **Build mode**: take an idea or topic and move it through all six stages so it comes out ready to
  film, edit, post and track.
- **Diagnose mode**: take a video or account that's underperforming, find the weakest of the six,
  and prescribe one fix for it.

Pick the mode from the request. "Help me make a video about X" means Build. "My reels aren't
getting views/leads" or a set of numbers means Diagnose. If it's unclear, start with Build.
It's more useful, and the scorecard at the end feeds Diagnose next time.

If the user's niche, audience or offer is already known (from memory, the repo or the
conversation), use it. Generic advice is the failure mode here.

---

## The six skills

### 1. Ideation: the biggest lever
A strong idea has three parts. Get all three right before writing anything:

- **Topic**: what it's about. Choose topics already *proven* in the niche, ones that perform
  for this creator or for peers. Proven demand makes performance predictable instead of a gamble.
- **Angle**: the specific take that makes it new. Examples are a contrarian view, a personal
  stake, "the mistake everyone makes", or a surprising number. The same topic with a sharper
  angle beats a new topic with a flat one.
- **Format**: how it's delivered. Examples are a talking head list, a story, a
  before/after, a reaction or a tutorial. Pick the format that suits the angle and that the
  creator can execute well.

In Build mode, give 3 idea variants (topic held constant, angle and format varied) and
recommend one. Say why.

### 2. Outlining: the HEIT framework
An idea is only as good as its execution. Outline with **Hook → Explain → Illustrate → Teach**:

- **Hook**: the first 1–3 seconds. Stop the scroll and open a loop.
- **Explain**: state the core idea plainly.
- **Illustrate**: make it concrete with an example, story, demo or before/after. This is
  the part people remember.
- **Teach**: the takeaway or action the viewer can use, followed by the CTA.

Write it as an **outline of beats**, not a word-for-word script, unless the user asks for a full
script. The outline is what makes delivery possible (see below).

### 3. Delivery: a trail, not a rail
Reading a script word for word sounds like reading. Treat the outline as a **trail**: the
creator can wander off to the sides (riff, add an aside, react) and then come back to the
middle. A **rail** locks them onto one fixed line. Give delivery notes:
- where to change **tone** (lighter, more serious, more urgent)
- **cadence** (where to speed up, where to pause before the payoff)
- 1–2 spots that invite a riff or a personal aside

### 4. Production: from raw footage to premium
Raw footage goes through a pipeline. The finishing work is what separates beginner videos
from advanced ones: on-screen text and graphics, motion, and cut timing. The highest-leverage
production move is a **roadmap**:
- Say or show up front how many parts there are ("6 skills…") and keep counting through them
  ("…which brings us to skill 4"). That keeps viewers watching to see the remaining items, and
  it's how the reel itself holds retention.

Give the user a short shot/edit list: roadmap cues, text overlays per beat, and where to cut
dead space. If they have raw footage to edit, hand off to the `talking-head-video-editor` skill.

### 5. Distribution: don't post into the dark
Give every video its best shot. Sam's Instagram play:
1. Post first as a **trial reel** (shown to non-followers).
2. Then post the same video again on the **main feed**.

That gives two chances at views for one round of effort. Suggest a caption, a comment-keyword
CTA if the user has a lead magnet, and the order and timing of the two posts. On other
platforms, adapt the principle (test first, then a full post) rather than the Instagram mechanics.

### 6. Analytics: views, followers, leads
Without a system, it's guessing. Track three numbers per video:
- **Views**: did the idea and hook reach people? (ideation, hook, distribution)
- **Followers**: did they want more from you? (angle, delivery, identity fit)
- **Leads**: did it turn into business? (teach, CTA, offer fit)

Use `assets/scorecard.csv` as the template. It imports straight into Google Sheets. Normalize
per 1,000 views so a viral outlier doesn't distort the picture.

---

## Diagnose mode

Use the numbers to point at a skill:

| Symptom | Likely weak skill | First fix |
|---|---|---|
| Low views across the board | Ideation (topic/angle) or Hook | Swap to a proven topic, sharpen the angle, rewrite the hook |
| Views okay, viewers drop early | Hook / Production | Tighten the first 3s, add a roadmap, cut dead space |
| Views okay, few followers | Angle / Delivery | A more distinctive point of view; riff more, read less |
| Followers okay, no leads | Teach + CTA / Distribution | Clear takeaway tied to the offer; comment-keyword CTA |
| Good videos, inconsistent reach | Distribution | Trial reel first, then main feed, every time |
| "No idea what's working" | Analytics | Start the scorecard today |

Name **one** weakest skill and **one** concrete fix for the next video. A list of ten fixes
gets none of them done. If the numbers are missing, ask for views, followers gained and leads
for the last ~5 videos, or offer the scorecard so they can start collecting them.

---

## Build mode output

```
## Idea
Topic: … | Angle: … | Format: …   (+ 2 alternates, one line each)

## Outline (HEIT)
Hook: …
Explain: …
Illustrate: …
Teach: … → CTA: …

## Delivery notes (trail, not rail)
…

## Production list
Roadmap cues: … | Overlays: … | Cuts: …

## Distribution
Trial reel → main feed plan, caption, CTA keyword

## Track it
Scorecard row prefilled (idea, topic, angle, format, hook) — fill in the numbers after 48–72h
```

Keep each section tight. The user should be able to film from this page.

Related skills to hand off to: `hook-library` for more hook options, `gap-hook` /
`persuasion-script-writing` / `ten-sentence-yapping-reel` for a full word-for-word script in a
specific structure, and `talking-head-video-editor` for the edit.
